from django import template
from django.db.models import Sum

from api.models import ApplyJob, Employee, Employer
from interview.models import Interviews

register = template.Library()


@register.filter
def get_shortlist(value):
    if value:
        shortlist = ApplyJob.objects.filter(job__job_key=value, status='shortlist').count()
        return shortlist
    else:
        return 0


@register.filter
def get_interviewed(value):
    if value:
        interviewed = Interviews.objects.filter(job__job_key=value).aggregate(Sum('submission'))
        print(interviewed)
        return interviewed['submission__sum']
    else:
        return 0


@register.filter
def get_options(value):
    if value:
        options = value.split(',')
        return options
    else:
        return []


@register.filter
def get_chat_head(value):
    try:
        employee = Employee.objects.get(uid=value)
        return employee
    except:
        employer = Employer.objects.get(uid=value)
        return employer


@register.filter
def get_chat_dp(value):
    if value.user.account_type == 'employee':
        return value.display_picture
    elif value.user.account_type == 'employer':
        return value.company_logo
