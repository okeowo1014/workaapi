from django.urls import path

from administrator import views

app_name = 'administrator'
urlpatterns = [
    path('employee/list/', views.employee_list_card, name='employee_list'),
    path('employer/list/', views.employer_list_card, name='employer_list'),
    path('jobs/list/', views.job_listing, name='jobs_list'),
    path('employee/<str:pid>/', views.employee_details, name='employee_details'),
    path('employer/<str:pid>/', views.employer_details, name='employer_details'),
    path('job/<str:job_key>/', views.job_details, name='job_details'),
    path('job/applications/<str:job_key>/', views.job_applications, name='job_applications'),
    path('interviews/', views.interview_list, name='interviews'),
    path('interview/submitted/<str:uid>', views.interview_submissions, name='interview_submitted'),
    path('interview/preview/answers/<str:iid>/<str:uid>', views.view_employee_interview_answer,
         name='interview_answers'),
    path('interview/preview/question/<str:iid>/', views.interview_questions, name='interview_question'),
    path('dm/chat/', views.admin_chat, name='admin_dm_chat'),
    path('staff/register', views.add_staff, name='add_staff'),
    path('staff/login', views.staff_login, name='staff_login'),
    path('', views.index, name='index'),

]
