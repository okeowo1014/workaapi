positions = ["Customer service representative", "Chief Technology Officer (CTO)", "Project manager", "Accountant",
             "Chief Marketing Officer (CMO)", "Chief Executive Officer (CEO)", "Human resource personnel", "Manager",
             "President", "Business analyst", "Marketing manager", "Marketing specialist", "Finance manager",
             "Product manager", "Chief Financial Officer (CFO) or Controller", "Executive assistants", "Vice President",
             "Administrative assistant", "Chief Operating Officer (COO)", "Human resources manager",
             "Sales representative", "Executive", "Operations and production"]
Industries = ["Retail", "Sales", "Healthcare", "Public services", "administration", "Leisure, sport and tourism",
              "Transport and logistics", "Media, News and internet", "Marketing", "advertising", "public relation",
              "Information technology", "Charity and voluntary work", "education", "Energy and utilities", "Law",
              "Business, consulting and management", "Hospitality and events management",
              "Law enforcement and security", "Social care", "Creative arts and design", "Recruitment and HR",
              "Engineering", "manufacturing", "Accountancy,", "Banking and finance", "Environment", "Agriculture",
              "Property Management", "Construction", "Science and pharmaceuticals", "Advertising and marketing",
              "Aerospace", "Agriculture", "Computer and technology", "Entertainment", "Fashion", "Food and beverage",
              "Mining", "Telecommunication"]
RelativeJobTags = ['Chief Technology Officer', 'CTO', 'R&D', 'Architect', 'Mobile', 'Software', 'Information', 'IT',
                   'IT', 'IT', 'Programmer', 'Developer', 'Coder', 'Objective C', 'Swift', 'Java', 'iOS', 'Android',
                   'Cordova', 'Phonegap', 'React Native', 'Ionic', 'Xcode', 'Quality', 'QA', 'Webmaster']
